import java.net.*;
import java.io.*;

public class SimpleSnifferClient {
    public static void main(String[] args) throws Exception {
        Socket socket = new Socket("localhost", 5000);
        PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

        System.out.println("Client connected to server.");
        for (int i = 1; i <= 5; i++) {
            String message = "Packet " + i + ": Hello from client!";
            out.println(message);
            System.out.println("Sent: " + message);
            Thread.sleep(1000); // 1 second delay between packets
        }

        out.close();
        socket.close();
    }
}

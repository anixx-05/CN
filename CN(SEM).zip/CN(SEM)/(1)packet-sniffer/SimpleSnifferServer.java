import java.net.*;
import java.io.*;

public class SimpleSnifferServer {
    public static void main(String[] args) throws Exception {
        ServerSocket server = new ServerSocket(5000); // open port 5000
        System.out.println("Server ready, waiting for client...");
        Socket socket = server.accept();

        System.out.println("Connection accepted!");
        System.out.println("Source (client) IP: " + socket.getInetAddress());
        System.out.println("Source port: " + socket.getPort());
        System.out.println("Destination (server) IP: " + socket.getLocalAddress());
        System.out.println("Destination port: " + socket.getLocalPort());
        System.out.println("Protocol: TCP");

        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        String line;
        while ((line = in.readLine()) != null) {
            System.out.println("Received Packet Data: " + line);
        }

        in.close();
        socket.close();
        server.close();
    }
}

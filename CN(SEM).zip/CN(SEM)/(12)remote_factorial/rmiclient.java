
import java.io.*;
import java.rmi.*;
public class rmiclient
{
public static void main(String args[])throws Exception
{
try
{
serverint f=(serverint)Naming.lookup("rmi://localhost:5000/abc");
DataInputStream m=new DataInputStream(System.in);
System.out.println("Enter the number\n");
int n1=Integer.parseInt(m.readLine());
System.out.println("The factorial number is "+f.fact(n1));
}
catch(Exception e)
{
System.out.println(e);
}
}
}
//Implementation code: serverimpl.java
import java.rmi.*;
import java.rmi.server.*;
public class serverimpl extends UnicastRemoteObject implements serverint
{
public serverimpl()throws Exception{
}
public int fact(int n)
{
int i,c=1;
for(i=1;i<=n;i++)
{
c=i*c;
}
return c;
}
}

//Client: Moveclient.java
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.net.*;
import java.io.*;
public class Moveclient extends JFrame implements MouseMotionListener{
JPanel mousepanel=new JPanel();
static Socket s;
static PrintWriter out;
int x,y;
String xs,ys;
public Moveclient()
{
super("Move the mouse over it");
mousepanel.setBackground(Color.BLACK);
setLayout(new GridLayout(1,1));
mousepanel.setSize(300,100);
add(mousepanel);
mousepanel.addMouseMotionListener(this);
}
public static void main(String args[])
{
try
{
s=new Socket("127.0.0.1",8500);
System.out.println("Connection Established");
out=new PrintWriter(s.getOutputStream(),true);
Moveclient m=new Moveclient();
m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
m.setSize(300,100);
m.setVisible(true);
}
catch(Exception e)
{
System.out.println("Exception: "+e);
}
}
public void mouseMoved(MouseEvent event)
{
x=event.getX();
y=event.getY();
xs=String.valueOf(x);
ys=String.valueOf(y);
out.println(xs);
out.println(ys);
}
public void mouseDragged(MouseEvent event)
{
}
}
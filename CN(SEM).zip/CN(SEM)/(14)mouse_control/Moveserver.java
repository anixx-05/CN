//Server: Moverserver.java
import java.awt.*;
import java.awt.event.*;
import java.awt.event.InputEvent;
import javax.swing.*;
import java.net.*;
import java.io.*;
import java.awt.Robot;
class Moveserver extends JFrame
{
JPanel mousepanel=new JPanel();
public Moveserver()
{
super("server");
mousepanel.setBackground(Color.BLACK);
setLayout(new GridLayout(1,1));
mousepanel.setSize(300,100);
add(mousepanel);
}
public static void main(String arg[])
{
String a,b;
Integer x,y;
boolean flag=true;
try{
ServerSocket ss=new ServerSocket(8500);
System.out.println("Server Listening.........");
Socket s=ss.accept();
System.out.println("Connection Established.....");
BufferedReader in =new BufferedReader(new InputStreamReader(s.getInputStream()));
Moveserver m=new Moveserver();
m.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
m.setSize(300,100);
m.setVisible(true);
Robot robot=new Robot();
while(flag){
a=in.readLine();
b=in.readLine();
x=Integer.valueOf(a);
y=Integer.valueOf(b);
robot.mouseMove(x,y);
m.repaint();
}
}
catch(Exception e)
{
System.out.println("Exception: "+e);
}
}
}

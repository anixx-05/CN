//Server : Mytelserver.java
import java.io.*;
import java.net.*;
public class Mytelserver
{
public static void main(String arg[])
{
String is;
String word;
boolean done = false;
try
{
ServerSocket serv=new ServerSocket(3333);
Socket sock=serv.accept();
System.out.println("Server started");
BufferedReader in=new BufferedReader(new InputStreamReader(sock.getInputStream()));
BufferedReader inp=new BufferedReader(new InputStreamReader(System.in));
PrintWriter out=new PrintWriter(sock.getOutputStream(),true);
System.out.println("hai the program started");
while(!done)
{
is=in.readLine();
System.out.println(is);
}
serv.close();
}
catch(Exception e)
{
System.out.println("Exception;"+e);
}
}
}

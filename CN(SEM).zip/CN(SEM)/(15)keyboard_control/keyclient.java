//Client: keyclient.java
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
public class keyclient extends Frame
{
Label label;
static Socket s;
static PrintWriter out;
TextField txtField;
public static void main(String[] args)
{
try
{
s=new Socket("127.0.0.1",3333);
System.out.println("Connection Established");
out =new PrintWriter(s.getOutputStream(), true);
keyclient k =new keyclient();
}
catch(Exception e)
{
System.out.println("Exception:"+e);
}
}
public keyclient()
{
super(" Key Press Event Frame");
Panel panel=new Panel();
label=new Label();
txtField=new TextField(20);
txtField.addKeyListener(new MyKeyListener());
add(label, BorderLayout.NORTH);
panel.add(txtField, BorderLayout.CENTER);
add(panel, BorderLayout.CENTER);
addWindowListener(new WindowAdapter() {
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
}
);
setSize(400,400);
setVisible(true);
}
public class MyKeyListener extends KeyAdapter
{
public void keyPressed (KeyEvent ke) {
char i=ke.getKeyChar();
String str=Character.toString(i);
out.println(str);
label.setText(str);}
}
}
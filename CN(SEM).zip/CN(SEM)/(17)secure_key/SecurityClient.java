//Client: SecurityClient.java
import java.io.*;
import java.net.*;
class SecurityClient
{
public static void main(String args[]) throws Exception
{
Socket s=new Socket("LocalHost",9000);
BufferedReader br=new BufferedReader(new InputStreamReader(s.getInputStream()));
int i=0,k1;
BufferedReader br1=new BufferedReader(new InputStreamReader(System.in));
String s3=" ";
String s2=br.readLine();
int k=Integer.parseInt(br.readLine());
System.out.println("RECEIVED MSG:"+s2);
System.out.println ("\n ENTER THE KEY:");
k1=Integer.parseInt(br1.readLine());
if(k==k1)
{
while(i<s2.length())
{
char c1=s2.charAt(i++);
int n=(int)c1-k1-1;
c1 = (char)n;
s3+=c1;
}
System.out.println("DECRYPTED STRING IS:"+s3);
s.close();
}}}
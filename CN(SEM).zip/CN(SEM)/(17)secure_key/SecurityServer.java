//Server: SecurityServer.java
import java.io.*;
import java.net.*;
class SecurityServer
{
public static void main(String args[]) throws Exception
{
try
{
ServerSocket ss=new ServerSocket(9000);
Socket s=ss.accept();
PrintStream ps=new PrintStream(s.getOutputStream());
BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
int i=0,k;
String s2="";
System.out.println("\n ENTER A STRING:");
String s1=br.readLine();
System.out.print(" \n ENTER THE KEY:");
k=Integer.parseInt(br.readLine());
while(i<s1.length())
{
char c1=s1.charAt(i++);
int n=(int)c1+k+1;
c1=(char)n;
s2+=c1;
}
System.out.println("ENCRYPTED STRING IS:"+s2);
ps.println(s2);
ps.println(k);
ps.close();
s.close();
ss.close();
}
catch(Exception e)
{
System.out.println("\n ERROR:"+e);
}}}

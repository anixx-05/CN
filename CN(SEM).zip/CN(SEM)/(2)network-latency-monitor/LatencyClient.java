import java.io.*;
import java.net.*;

public class LatencyClient {
    public static void main(String[] args) {
        String host = "127.0.0.1"; // or server IP
        int port = 5000;

        try {
            System.out.println(" Connecting to server " + host + ":" + port + " ...");
            Socket socket = new Socket(host, port);
            System.out.println(" Connected to server.");

            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            System.out.println("Sending timestamp to server...");
            long start = System.currentTimeMillis();
            out.writeLong(start);

            System.out.println(" Waiting for server response...");
            long echoedTime = in.readLong();
            long end = System.currentTimeMillis();

            long rtt = end - start;
            System.out.println(" Received echo reply from server.");
            System.out.println(" Round Trip Time (RTT): " + rtt + " ms");

            socket.close();
            Sy

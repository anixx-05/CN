import java.io.*;
import java.net.*;

public class LatencyServer {
    public static void main(String[] args) {
        int port = 5000; // Change if needed

        try (ServerSocket serverSocket = new ServerSocket(port)) {
            System.out.println(" Server started. Listening on port " + port);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("\nClient connected from " + socket.getInetAddress().getHostAddress());

                DataInputStream in = new DataInputStream(socket.getInputStream());
                DataOutputStream out = new DataOutputStream(socket.getOutputStream());

                // Receive timestamp from client
                long sentTime = in.readLong();
                System.out.println(" Received timestamp from client.");

                // Immediately echo it back
                out.writeLong(sentTime);
                System.out.println(" Sent echo reply back to client.");

                socket.close();
                System.out.println(" Client disconnected.\n");
            }

        } catch (IOException e) {
            System.out.println(" Server error: " + e.getMessage());
        }
    }
}

import java.net.*;
import java.io.*;
import java.util.*;

public class QuizClient {
    public static void main(String[] args) {
        String serverHost = "127.0.0.1";
        int serverPort = 5001;
        Scanner sc = new Scanner(System.in);

        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName(serverHost);

            // Send initial connection message
            String startMsg = "START";
            byte[] startData = startMsg.getBytes();
            DatagramPacket startPacket = new DatagramPacket(startData, startData.length, serverAddress, serverPort);
            socket.send(startPacket);

            for (int i = 0; i < 5; i++) {
                // Receive question
                DatagramPacket qPacket = new DatagramPacket(new byte[1024], 1024);
                socket.receive(qPacket);
                String question = new String(qPacket.getData(), 0, qPacket.getLength());
                System.out.println(question);
                System.out.print("Your answer: ");
                String answer = sc.nextLine();

                // Send answer
                byte[] ansData = answer.getBytes();
                DatagramPacket ansPacket = new DatagramPacket(ansData, ansData.length, serverAddress, serverPort);
                socket.send(ansPacket);
            }

            // Receive score
            DatagramPacket resultPacket = new DatagramPacket(new byte[1024], 1024);
            socket.receive(resultPacket);
            String result = new String(resultPacket.getData(), 0, resultPacket.getLength());
            System.out.println(result);

            socket.close();
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }
}

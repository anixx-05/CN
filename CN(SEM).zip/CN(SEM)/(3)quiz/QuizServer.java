import java.net.*;
import java.io.*;

public class QuizServer {
    public static void main(String[] args) {
        int port = 5001;
        String[][] questions = {
            {"What is the capital of Greece?", "Athens"},
            {"2 + 2 = ?", "4"},
            {"Who developed Java?", "James Gosling"},
            {"Which planet is known as the Red Planet?", "Mars"},
            {"What is the square root of 16?", "4"}
        };

        try {
            DatagramSocket socket = new DatagramSocket(port);
            System.out.println("Server started. Waiting for client...");

            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            socket.receive(packet);

            InetAddress clientAddress = packet.getAddress();
            int clientPort = packet.getPort();
            System.out.println("Client connected from " + clientAddress + ":" + clientPort);

            int score = 0;

            for (int i = 0; i < questions.length; i++) {
                // Send question
                String q = "Q" + (i + 1) + ": " + questions[i][0];
                byte[] qData = q.getBytes();
                DatagramPacket qPacket = new DatagramPacket(qData, qData.length, clientAddress, clientPort);
                socket.send(qPacket);

                // Receive answer
                DatagramPacket ansPacket = new DatagramPacket(new byte[1024], 1024);
                socket.receive(ansPacket);
                String answer = new String(ansPacket.getData(), 0, ansPacket.getLength()).trim();

                if (answer.equalsIgnoreCase(questions[i][1])) {
                    score++;
                }
            }

            // Send final score
            String result = "Your Score: " + score + "/" + questions.length;
            byte[] resultData = result.getBytes();
            DatagramPacket resultPacket = new DatagramPacket(resultData, resultData.length, clientAddress, clientPort);
            socket.send(resultPacket);

            System.out.println("Quiz completed for client.");
            socket.close();

        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }
}

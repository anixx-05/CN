import java.net.*;
import java.io.*;
import java.util.*;

public class BuzzerClient {
    public static void main(String[] args) {
        String serverHost = "127.0.0.1";
        int serverPort = 5003;
        Scanner sc = new Scanner(System.in);

        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName(serverHost);

            // Register with server
            String joinMsg = "JOIN";
            byte[] joinData = joinMsg.getBytes();
            DatagramPacket joinPacket = new DatagramPacket(joinData, joinData.length, serverAddress, serverPort);
            socket.send(joinPacket);
            System.out.println("Joined the quiz buzzer system.");

            // Wait for questions and reply
            for (int i = 0; i < 3; i++) {
                DatagramPacket qPacket = new DatagramPacket(new byte[1024], 1024);
                socket.receive(qPacket);
                String question = new String(qPacket.getData(), 0, qPacket.getLength());
                System.out.println("Question: " + question);
                System.out.println("Press ENTER to buzz and type your answer quickly...");

                sc.nextLine(); // wait for ENTER to simulate buzzer
                System.out.print("Your answer: ");
                String answer = sc.nextLine();

                byte[] ansData = answer.getBytes();
                DatagramPacket ansPacket = new DatagramPacket(ansData, ansData.length, serverAddress, serverPort);
                socket.send(ansPacket);

                // Receive result
                DatagramPacket resPacket = new DatagramPacket(new byte[1024], 1024);
                socket.receive(resPacket);
                String result = new String(resPacket.getData(), 0, resPacket.getLength());
                System.out.println(result);
                System.out.println();
            }

            socket.close();
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }
}

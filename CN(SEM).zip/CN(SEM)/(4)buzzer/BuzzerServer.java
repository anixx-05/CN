import java.net.*;
import java.io.*;

public class BuzzerServer {
    public static void main(String[] args) {
        int port = 5003;
        String[] questions = {
            "Identify the movie: A robot protects a boy.",
            "Identify the song: 'Shape of You' singer?",
            "Guess the movie: A ship sinks in the Atlantic Ocean."
        };

        try {
            DatagramSocket socket = new DatagramSocket(port);
            System.out.println("Server started. Waiting for clients...");

            // Wait for clients to register
            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

            // Collect 2 clients for demo (you can increase)
            InetAddress[] clients = new InetAddress[2];
            int[] clientPorts = new int[2];
            for (int i = 0; i < 2; i++) {
                socket.receive(packet);
                clients[i] = packet.getAddress();
                clientPorts[i] = packet.getPort();
                System.out.println("Client " + (i + 1) + " joined from " + clients[i] + ":" + clientPorts[i]);
            }

            // Ask questions
            for (String q : questions) {
                System.out.println("Question: " + q);

                // Send question to all clients
                byte[] qData = q.getBytes();
                for (int i = 0; i < clients.length; i++) {
                    DatagramPacket qPacket = new DatagramPacket(qData, qData.length, clients[i], clientPorts[i]);
                    socket.send(qPacket);
                }

                // Wait for first buzzer
                DatagramPacket buzzerPacket = new DatagramPacket(new byte[1024], 1024);
                socket.receive(buzzerPacket);
                String response = new String(buzzerPacket.getData(), 0, buzzerPacket.getLength()).trim();
                InetAddress winnerAddr = buzzerPacket.getAddress();
                int winnerPort = buzzerPacket.getPort();

                String winnerMsg = "Winner: " + winnerAddr.getHostAddress() + " answered: " + response;
                System.out.println(winnerMsg);

                // Send result to all clients
                byte[] resultData = winnerMsg.getBytes();
                for (int i = 0; i < clients.length; i++) {
                    DatagramPacket resPacket = new DatagramPacket(resultData, resultData.length, clients[i], clientPorts[i]);
                    socket.send(resPacket);
                }
            }

            System.out.println("Quiz completed.");
            socket.close();

        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }
}

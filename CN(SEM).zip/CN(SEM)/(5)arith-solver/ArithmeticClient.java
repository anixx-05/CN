import java.net.*;
import java.io.*;
import java.util.*;

public class ArithmeticClient {
    public static void main(String[] args) {
        String serverHost = "127.0.0.1";
        int serverPort = 5002;
        Scanner sc = new Scanner(System.in);

        try {
            DatagramSocket socket = new DatagramSocket();
            InetAddress serverAddress = InetAddress.getByName(serverHost);

            System.out.print("Enter arithmetic expression (e.g., 10 + 5 * 2): ");
            String expression = sc.nextLine();

            // Send expression to server
            byte[] sendData = expression.getBytes();
            DatagramPacket sendPacket = new DatagramPacket(sendData, sendData.length, serverAddress, serverPort);
            socket.send(sendPacket);

            // Receive result
            DatagramPacket recvPacket = new DatagramPacket(new byte[1024], 1024);
            socket.receive(recvPacket);
            String result = new String(recvPacket.getData(), 0, recvPacket.getLength());

            System.out.println(result);

            socket.close();
        } catch (IOException e) {
            System.out.println("Client error: " + e.getMessage());
        }
    }
}

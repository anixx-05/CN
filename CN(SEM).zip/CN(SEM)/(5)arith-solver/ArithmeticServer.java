import java.net.*;
import java.io.*;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;

public class ArithmeticServer {
    public static void main(String[] args) {
        int port = 5002;

        try {
            DatagramSocket socket = new DatagramSocket(port);
            System.out.println("Server started. Waiting for client...");

            byte[] buffer = new byte[1024];
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

            // Wait for client request
            socket.receive(packet);
            String expression = new String(packet.getData(), 0, packet.getLength()).trim();
            System.out.println("Received expression from client: " + expression);

            // Evaluate the expression using JavaScript engine
            ScriptEngine engine = new ScriptEngineManager().getEngineByName("JavaScript");
            String result;
            try {
                Object output = engine.eval(expression);
                result = "Result: " + output.toString();
            } catch (Exception e) {
                result = "Invalid Expression";
            }

            // Send back result to client
            InetAddress clientAddress = packet.getAddress();
            int clientPort = packet.getPort();
            byte[] resultData = result.getBytes();
            DatagramPacket resultPacket = new DatagramPacket(resultData, resultData.length, clientAddress, clientPort);
            socket.send(resultPacket);

            System.out.println("Sent result to client: " + result);
            socket.close();
        } catch (IOException e) {
            System.out.println("Server error: " + e.getMessage());
        }
    }
}
